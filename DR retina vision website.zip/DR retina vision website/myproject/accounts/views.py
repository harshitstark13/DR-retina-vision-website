from django.contrib.auth.forms import *
from django.shortcuts import render, redirect
from django.contrib.auth import authenticate, login as auth_login
from django.contrib.auth.forms import UserCreationForm
from django.contrib.auth.models import User
from django.contrib import messages
from django.core.files.storage import default_storage  # Add this import
from django.core.files.base import ContentFile  # Add this import

# Login view
def login_view(request):
    if request.method == "POST":
        username = request.POST.get('username')
        password = request.POST.get('password')
        user = authenticate(request, username=username, password=password)
        if user is not None:
            auth_login(request, user)
            return redirect('home')  # Redirect to home page after successful login
        else:
            messages.error(request, "Invalid username or password")  # Use messages for better feedback
            return render(request, 'login.html')

    return render(request, 'login.html')

# Register view with auto-login after registration
def register_view(request):
    if request.method == 'POST':
        form = UserCreationForm(request.POST)
        if form.is_valid():
            user = form.save()  # Save the new user into the database
            username = form.cleaned_data.get('username')
            password = form.cleaned_data.get('password1')
            messages.success(request, "Registration successful. You are now logged in.")

            # Automatically log the user in after registration
            user = authenticate(username=username, password=password)
            if user is not None:
                auth_login(request, user)
                return redirect('home')  # Redirect to home page after successful login
        else:
            messages.error(request, "There was an error in your registration form.")
            return render(request, 'login.html', {'form': form, 'show_registration': True})

    else:
        form = UserCreationForm()

    return render(request, 'login.html', {'form': form, 'show_registration': True})

# Image upload view
def upload_image_view(request):
    if request.method == "POST" and request.FILES.get('imageUpload'):
        image = request.FILES['imageUpload']
        
        # Use a unique filename to avoid overwriting files
        file_name = default_storage.get_available_name(image.name)
        default_storage.save(file_name, ContentFile(image.read()))  # Correctly handle file storage
        
        # Add feedback for successful upload
        messages.success(request, "Image uploaded successfully")
        return redirect('preview')  # Redirect after successful upload

    return render(request, 'upload_image.html')  # Update to the appropriate template for image upload

# Home view
def home_view(request):
    return render(request, 'index.html')

# Preview view
def preview_view(request):
    return render(request, 'preview.html')

# Performance analysis view
def performance_analysis_view(request):
    return render(request, 'performance_analysis.html')
